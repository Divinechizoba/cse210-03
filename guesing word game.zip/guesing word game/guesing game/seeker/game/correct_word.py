import random
from game.seeker import Seeker


class Hider:
    """The person hiding from the Seeker. 

    The responsibility of Hider is to keep track of its location and distance from the seeker. 

    Attributes:
        _location (int): The location of the hider (1-1000).
        _distance (List[int]): The distance from the seeker.
    """

    def __init__(self):
        """Constructs a new Hider.

        Args:
            self (Hider): An instance of Hider.
        """
        self._words = [
            'GAME OVER',
        ]
        self._word = random.choice(self._words).upper()
        self._answer = []
        self._parachute = [
            ' ___',
            '/___\ ',
            '\   /',
            ' \ /',
            '  O',
            ' /|\ ',
            ' / \ ',
            '',
            '^^^^^^^'
        ]
        self._lives = 4
        for i in self._word:
            if i == ' ':
                self._answer.append(' ')
            else:
                self._answer.append('_')

    
    def is_game_over(self):
        """Whether or not the word has been found.

        Args:
            self (Hider): An instance of Hider.

        Returns:
            boolean: True if the hider was found; false if otherwise.
        """
        isover = False
        if self._lives == 0:
            print("game over")
            isover = True
        if '_' not in self._answer:
            print("you won")
            isover = True

        return isover

    def watch_seeker(self, seeker):
        """Watches the word.

        Args:
            self (Hider): An instance of Hider.
        """

        ans = seeker.get_location()
        if ans in self._word:
            for i in range(len(self._word)):
                if self._word[i] == ans:
                    self._answer[i] = ans
        else:
            self._lives = self._lives - 1
            self._parachute.pop(0)
            if self._lives == 0:
                self._parachute[0] = '  x'
