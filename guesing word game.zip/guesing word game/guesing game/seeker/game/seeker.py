import random


class Seeker:
    """Helps check if the word been typed corresponds withthe given word 
    """

    def __init__(self):
        """Constructs a new Seeker.

        Args:
            self (Seeker): An instance of Seeker.
        """
        self._location = ""

    def get_location(self):
        """Gets the current location.

        Returns:
            number: The current location,
        """
        return self._location

    def move_location(self, ans):
        """.

        Args:
            self (Seeker): An instance of Seeker.
            ans: checks if the answer corresponds. 
        """
        self._location = ans
